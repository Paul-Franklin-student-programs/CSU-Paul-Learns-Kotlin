# First-Kotlin-App
A to-do list manager that helps users add tasks, mark tasks as complete, and display all task information
